<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function send_email($to, $subject, $content){
    require 'vendor/autoload.php';

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'miladona67@gmail.com';
        $mail->Password   = 'capuzalpvqnhrtfc';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom('miladona67@gmail.com', 'Library Attendance OTP');
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $content;
        
        $mail->send();
        echo "OTP Has Been Sent Successfully!";
    } catch (Exception $e) {
        echo "OTP Could not be sent Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
