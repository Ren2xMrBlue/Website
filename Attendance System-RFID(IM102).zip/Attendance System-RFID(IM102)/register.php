<!-- register.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="register.css">
    <style>     
    </style>
</head>
<body>
    <div class="login-container">
        <?php
        session_start();
        include("ias102db.php");
        include("email.php");

        function isEmailRegistered($email)
            {   
            global $conn;
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            if ($stmt->error) {
                die("Error during email check: " . $stmt->error);
            }
            $result = $stmt->get_result();
            $stmt->close();

            return $result->num_rows > 0;
            }

        if (isset($_POST["submit"])) {
            $fullName = $_POST["fullName"];
            $email = $_POST["email"];
            $password = $_POST["password"];
            $passwordRepeat = $_POST["re_password"];
            $passwordHint = $_POST["password_hint"];

          
            $errors = array();

            if (empty($fullName) || empty($email) || empty($password) || empty($passwordRepeat)) {
                array_push($errors, "All fields are required");
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                array_push($errors, "Email is not valid");
            }
            $checkEmailQuery = "SELECT user_email FROM register WHERE user_email=?";
            $checkStmt = mysqli_stmt_init($con);
            if (mysqli_stmt_prepare($checkStmt, $checkEmailQuery)) {
            mysqli_stmt_bind_param($checkStmt, "s", $email);
            mysqli_stmt_execute($checkStmt);
            mysqli_stmt_store_result($checkStmt);
            if (mysqli_stmt_num_rows($checkStmt) > 0) {
            array_push($errors, "Email address is already registered");
                }

        mysqli_stmt_close($checkStmt);
    }

            if (strlen($password) < 8) {
                array_push($errors, "Password must be at least 8 characters long");
            }
            if ($password !== $passwordRepeat) {
                array_push($errors, "Master Password does not match");
            }
            if (count($errors) > 0) {
                foreach ($errors as $error) {
                    echo "<div class='alert alert-danger'>$error</div>";
                }
            } else {
                $_SESSION['fullName'] = $fullName;
                $_SESSION['email'] = $email;
                $_SESSION['password'] = $password;
                $_SESSION['passwordHint'] = $passwordHint;

                $otp = generateOTP();
                $_SESSION['otp'] = $otp;

                verifyOTP($email, "PHP OTP LOGIN", $otp);
                header("location:register2fa.php");
                exit();
            }
        }

        function generateOTP()
        {
            return rand(10000, 99999);
        }
        ?>

        <h2>Register</h2>
        <div class="container">
        
            <form action="register.php" method="post">
            <div class="form-group">
                    <input type="email" class="form-control" name="email" placeholder="Email Address" required>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="fullName" placeholder="Full Name" required>
                </div>    
                <div class="form-group">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Master Password" required >
                       
                        <img src="images/view.png" alt="Eye icon" id="eyeicon">           
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="re_password" id="re_password" placeholder="Re-Enter Master Password" required>
                        
                        <img src="images/view.png" alt="Eye icon" id="eyeicon1">     
                       
                </div>
              
                <div class="form-group"> 
                
                    <label for="password_hint" class="form-label">Password Hint:</label> 
                    <textarea class="form-control non-resizable" name="password_hint"  rows="3" placeholder="Enter a hint to help you remember your password"></textarea>   
                    <h6 style="margin-top: 5px;">(Recommended)<h6>  
                </div>
             
                <div class="form-btn">
                 <input type="submit" class="btn btn-primary" value="Register" name="submit">
                </div>
            </form>
        </div>
    </div>

    <script>    
           function togglePasswordVisibility(inputId, eyeIconId) {
        let eyeIcon = document.getElementById(eyeIconId);
        let passwordInput = document.getElementById(inputId);

        eyeIcon.onclick = function(){
            if(passwordInput.type == "password"){
                passwordInput.type = "text";
            } else {
                passwordInput.type ="password";
            }
        };
    }
    togglePasswordVisibility("password", "eyeicon");
    togglePasswordVisibility("re_password", "eyeicon1");   
    </script>
</body>
</html>
