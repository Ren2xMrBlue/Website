<?php
session_start();
include_once 'db_connect.php'; // Include your database connection file
include_once 'email.php'; // Include your email sending script

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    // Check if the email exists in the database
    $stmt = $con->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows == 1) {
        // Generate OTP
        $otp = rand(100000, 999999);

        // Store OTP and email in session
        $_SESSION['email'] = $email;
        $_SESSION['otp'] = $otp;

        // Update user_otp field in the database
        $stmt = $con->prepare("UPDATE admin SET user_otp = ? WHERE username = ?");
        $stmt->bind_param("ss", $otp, $email);
        $stmt->execute();
        $stmt->close();

        // Send OTP to user's email
        $subject = "OTP for Password Reset";
        $content = "Your OTP for Password Reset is: $otp";
        send_email($email, $subject, $content);

        echo "<p>An OTP has been sent to your email address. Please check your email and enter the OTP below.</p>";

        // Redirect to enter OTP page
        header("Location: enterotp.php");
        exit();
    } else {
        echo "Email not found. Please enter a valid email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #005a8d;
        }
        p {
            color: #333333;
        }
        label {
            color: #333333;
            font-weight: bold;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #cccccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #005a8d;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #00364d;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <p>Enter your email address to receive a one-time password (OTP) for resetting your password.</p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>
            <input type="submit" value="Send OTP">
        </form>
    </div>
</body>
</html>