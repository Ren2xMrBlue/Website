<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Two Factor Authentication</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        h2 {
            color: #007bff;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            margin-bottom: 5px;
            text-align: center;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn-success {
            background-color: #28a745;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .alert-primary {
            color: #004085;
            background-color: #cce5ff;
            border: 1px solid #b8daff;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        body {
            background: url('images/bg2.jpg') no-repeat center center fixed;
            background-size: cover;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <?php
          session_start();
          include("ias102db.php");
          include("email.php");

          if (isset($_REQUEST['msg'])) {
              echo '<span style="color: red;">' . $_REQUEST['msg'] . '</span>';
          }

          if ($_SERVER['REQUEST_METHOD'] === 'POST') {
              $otp = $_POST['user_otp'];

              if ($otp == $_SESSION['otp']) {
                  $fullName = $_SESSION['fullName'];
                  $email = $_SESSION['email'];
                  $password = $_SESSION['password'];
                  $passwordHint = $_SESSION['passwordHint'];

                  $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                  $insertQuery = "INSERT INTO register (user_email, fullName, masterpassword, user_otp, password_hint) VALUES (?, ?, ?, ?, ?)";
                  $stmt = mysqli_stmt_init($con);

                  if (mysqli_stmt_prepare($stmt, $insertQuery)) {
                      mysqli_stmt_bind_param($stmt, "sssss", $email, $fullName, $hashedPassword, $otp, $passwordHint);
                      mysqli_stmt_execute($stmt);

                      header("location:success.php");
                      exit();
                  } else {
                      die("Something went wrong");
                  }
              } else {
                  header("location:" . htmlspecialchars($_SERVER["PHP_SELF"]) . "?msg= OTP is incorrect!");
                  exit();
              }
          }
        ?>
        <h2>Two Factor Authentication</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="user_otp" class="form-label">Enter OTP:</label>
                <input type="number" class="form-control" name="user_otp" placeholder="5 Digit Code" oninput="this.value = this.value.slice(0, 5)" required>
            </div>

            <div class="form-group">
                <button type="submit" class="btn-success">Verify OTP</button>
            </div>
        </form>
    </div>
</body>

</html>
