<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance | LIBRARY Attendance Management System</title>
    <link rel="stylesheet" href="Font-Awesome-master/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="DataTables/datatables.min.css">
    <script src="DataTables/datatables.min.js"></script>
    <script src="Font-Awesome-master/js/all.min.js"></script>
    <script src="js/script.js"></script>
    <link rel="stylesheet" href="css/aa.css">
    <style>
        html,body{
            height:100%;
            width:100%;
            background-image: url('SPCT.jpg'); 
            background-size: cover; 
            background-repeat: no-repeat; 
            background-position: center; 
        }
        main{
            height:100%;
            display:flex;
            flex-flow:column;
        }
        #page-container{
            flex: 1 1 auto; 
            overflow:auto;
        }
        #topNavBar{
            flex: 0 1 auto; 
        }
        .truncate-1 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
        }
        .truncate-3 {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }

        #msg {
            font-size: 20px;
        }
        .modal-dialog.large {
            width: 80% !important;
            max-width: unset;
        }
        .modal-dialog.mid-large {
            width: 50% !important;
            max-width: unset;
        }
        @media (max-width:720px){
            .modal-dialog.large {
                width: 100% !important;
                max-width: unset;
            }
            .modal-dialog.mid-large {
                width: 100% !important;
                max-width: unset;
            }  
        }
    </style>
</head>
<body>
    <main class="text-dark">
        <div class="container py-3 d-flex flex-column " id="page-container">
            <div class="w-100 h-25 d-flex  align-items-center">
            </div>
            <div class="w-100 row flex-grow-1">
                <div class="col-md-6 d-flex flex-column align-items-center h-100 mx-auto">
                    <div class="w-80 h-25 d-flex align-items-center">
                        <div class="w-60">
                            <h2 class="text-center"><b><span id="time_display">11:12 PM</span></b></h2>
                            <h3 class="text-center"><b><span id="date_display">Jan 23,2023 </span></b></h3>
                            <input type="hidden" id="date_time" value="">
                        </div>
                    </div>
                    <div class="w-100 h-55 d-flex align-items-center">
                        <div class="w-100">
                            <div class="card text-dark h-auto">
                                <div class="card-body bg-transparent" style="border: 1px solid navy;">
                                    <center><h2>Please SCAN YOUR ID</h2></center>
                                    
                                    <div class="form-group">
                                        <center><small id="msg"></small></center>
                                        <input type="text" autofocus class="form-control form-control-sm rounded-100" id="student_code">
                                    </div>
                                    <div class="form-group d-flex justify-content-between mt-3 mb-1">
                                        <!-- IN and OUT buttons -->
                                        <button class="att_btn btn btn-primary rounded-pill py-0 col-lg-4 col-md-6 col-sm-14" type="button" data-id="1" id="time_in_btn">TIME IN</button>
                                        <button class="att_btn btn btn-danger rounded-pill py-0 col-lg-4 col-md-6 col-sm-14" type="button" data-id="2" id="time_out_btn">TIME OUT</button>
                                    </div>
                                </div>
                            <center><a href="./index.php" class="mt-4 text-dark"><b>Go to Admin Side</b></a></center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <!-- Added HTML, CSS, and JavaScript for attendance -->
    <script>
    var studentStates = {}; // Object to store state (Time In or Time Out) for each student

    function date_time() {
        var currentdate = new Date(); 
        var datetime = "Last Sync: " + currentdate.getDate() + "/"
                + (currentdate.getMonth()+1)  + "/" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        var _m = months[currentdate.getMonth()];
        var _Y = currentdate.getFullYear();
        var _d = String(currentdate.getDate()).padStart(2, '0');
        $('#date_display').text(_m + ' ' + _d + ', ' + _Y);
        var _h = currentdate.getHours() > 12 ? String(currentdate.getHours() - 12).padStart(2, '0') : String(currentdate.getHours()).padStart(2, '0');
        var _H = String(currentdate.getHours()).padStart(2, '0');
        var _mm = String(currentdate.getMinutes()).padStart(2, '0');
        var _a = currentdate.getHours() >= 12 ? "PM" : "AM";
        var _s = String(currentdate.getSeconds()).padStart(2, '0');
        $('#time_display').text(_h + ':' + _mm + ':' + _s + ' ' + _a);
        $('#date_time').val(_Y + '-' + String(currentdate.getMonth() + 1).padStart(2, '0') + '-' + _d + ' ' + _H + ':' + _mm + ':' + _s);
    }

    $(function() {
        date_time(); // To initially set the date and time
        setInterval(date_time, 1000); // Update every second

        $('#student_code').on('change', function() {
            var sCode = $(this).val();
            if (!sCode) return; // Exit if no code is scanned

            var currentState = studentStates[sCode];
            if (!currentState || currentState === 'Time Out') {
                // Perform Time In if the student is not already timed in
                $('#time_in_btn').click(); // Trigger Time In button click
            } else {
                // Perform Time Out if the student is already timed in
                $('#time_out_btn').click(); // Trigger Time Out button click
            }
        });

        $('.att_btn').click(function() {
            $('#msg').removeClass('text-danger text-success').text('');
            var sCode = $('#student_code').val();
            $("#student_code").removeClass('border-danger');
            if(sCode == ''){
                $("#student_code").addClass('border-danger').focus();
                return false;
            }
            var dateTime = $('#date_time').val();
            
            // Check the state of the student
            var currentState = studentStates[sCode];
            var att_type;
            if (!currentState || currentState === 'Time Out') {
                // If the state is undefined or Time Out, it means it's Time In
                att_type = 1; // Time In
                studentStates[sCode] = 'Time In'; // Update state to Time In
            } else {
                // If the state is Time In, it means it's Time Out
                att_type = 2; // Time Out
                studentStates[sCode] = 'Time Out'; // Update state to Time Out
            }

            $('.att_btn').attr('disabled', true);
            $.ajax({
                url:'Actions.php?a=save_attendance',
                method:'POST',
                data:{student_code:sCode,att_type:att_type,date_created:dateTime},
                dataType:'json',
                error: err => {
                    console.log(err);
                    $('.att_btn').attr('disabled', false);
                },
                success: function(resp){
                    if(resp.status == 'success'){
                        if(att_type == 1) {
                            $('#msg').addClass('text-success').text('WELCOME TO SPCT LIBRARY');
                        } else {
                            $('#msg').addClass('text-success').text('THANK YOU, COME AGAIN.');
                        }
                    } else if(resp.status =='failed' && resp.msg){
                        var msg_h= $('#msg');
                        msg_h.addClass('text-danger');
                        msg_h.text(resp.msg);
                    }
                    $('.att_btn').attr('disabled', false);
                }
            });
            $('#student_code').val(''); // Clearing the text box
        });
    });
    </script>
</body>
</html>
