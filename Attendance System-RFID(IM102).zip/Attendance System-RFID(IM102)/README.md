# attendance_system


website demo :
http://attendance107.000webhostapp.com/

username : test

password : 123

-----------------------------------
> [link to watch video in youtube](https://youtu.be/8IRmAF91mFI)
-----------------------------------
photo 

![image](https://user-images.githubusercontent.com/120535197/214313044-d54c9ea9-cb9c-4f8e-a07d-f0bfeafa612a.png)

![image](https://user-images.githubusercontent.com/120535197/214313152-6654b212-7c28-47d0-926e-bf9227985ff3.png)

![image](https://user-images.githubusercontent.com/120535197/214313208-822a5135-fbf3-4d8e-a4fb-675ace4d3955.png)

![image](https://user-images.githubusercontent.com/120535197/214313296-efb2c4f1-f3da-4f24-8e54-0db28d290b11.png)

![image](https://user-images.githubusercontent.com/120535197/214313358-29ab46e6-dbfd-41e0-9535-a13da4d6327c.png)

![image](https://user-images.githubusercontent.com/120535197/214313407-41fa8e2c-e1b6-4e61-acd2-29aea9095485.png)

![image](https://user-images.githubusercontent.com/120535197/214313470-c19c3cab-9609-4180-97a3-806693e5f399.png)

![image](https://user-images.githubusercontent.com/120535197/214313509-85986f06-f8a1-433a-8160-81222630b20b.png)

![image](https://user-images.githubusercontent.com/120535197/214313600-7ed47e6e-f096-497c-8bf6-e5761f5e889a.png)

