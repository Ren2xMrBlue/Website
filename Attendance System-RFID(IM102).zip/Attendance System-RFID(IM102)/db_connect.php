<?php


    $hostName = "localhost";
    $dbUser="root";
    $dbPassword ="";
    $dbName ="attendance";
    $con = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName) or die (mysqli_error($con));
    $db=mysqli_select_db($con, "attendance") or die (mysqli_error($con));
   
  
?>