<?php
// Include the database connection
require_once("classes/db_conn.class.php");

// Initialize the database connection
$db = new db_conn();
$conn = $db->connect();

// Query to delete all records from the attendance_list table
$sql = "DELETE FROM attendance_list";

try {
    // Prepare and execute the SQL query
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Return success message as JSON
    echo json_encode(array("status" => "success", "message" => "Attendance records cleared successfully"));
} catch (PDOException $e) {
    // Return error message as JSON
    echo json_encode(array("status" => "error", "message" => "Error clearing attendance records: " . $e->getMessage()));
}
?>
