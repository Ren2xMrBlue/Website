<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Student Attendance Management System - LIBRARY</title>
    <!-- Add your CSS and other necessary links here -->
    <style>
        body {
            background-image: url('ADMIN PAGE.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body>
    <div class="container py-3" id="page-container">
        <hr>
        <!-- Your other content here -->
    </div>
</body>
</html>
