/*
SQLyog Community v13.2.1 (64 bit)
MySQL - 10.4.32-MariaDB : Database - attendance
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`attendance` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `attendance`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `data_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `admin` */

insert  into `admin`(`admin_id`,`name`,`username`,`password`,`data_added`) values 
(1,'Jabbe Charles','Jabbe02','$2y$10$TwJdyh9KMUJEH48CTB7e6eyIcOB.qQ4glhsTd.7zM5pWkdO57Wu02','2023-01-20 21:25:45'),
(2,'mohamed nasr','medo','$2y$10$OdezC.QU8xTg7kG7qP8.a.zF1p2rBAPkl4Suppq.GsM.2Fgj7kjHC','2023-01-20 23:27:56'),
(3,'Jabbe','Jabbe123','jabbe123','2024-02-21 22:06:26');

/*Table structure for table `attendance_list` */

DROP TABLE IF EXISTS `attendance_list`;

CREATE TABLE `attendance_list` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `date_updated` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `attendance_list` */

insert  into `attendance_list`(`attendance_id`,`student_id`,`type`,`date_updated`,`date_created`) values 
(15,'22',1,'Feb 21 ,2024 04:12 PM','2024-02-21 23:12:18'),
(16,'23',1,'Feb 21 ,2024 04:14 PM','2024-02-21 23:14:19'),
(17,'21',1,'Feb 21 ,2024 04:15 PM','2024-02-21 23:15:50'),
(18,'21',2,'Feb 21 ,2024 04:15 PM','2024-02-21 23:15:55'),
(19,'20',1,'Feb 21 ,2024 04:17 PM','2024-02-21 23:17:21'),
(20,'20',2,'Feb 21 ,2024 04:17 PM','2024-02-21 23:17:23');

/*Table structure for table `course_list` */

DROP TABLE IF EXISTS `course_list`;

CREATE TABLE `course_list` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(60) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `course_list` */

insert  into `course_list`(`course_id`,`course_code`,`status`,`date_added`) values 
(1,'EDUC',1,'2023-01-21 00:27:35'),
(2,'BPED',1,'2023-01-21 00:27:35'),
(3,'BSBA',1,'2023-01-21 00:27:51'),
(4,'BSIT',1,'2023-01-21 00:27:51');

/*Table structure for table `school_year` */

DROP TABLE IF EXISTS `school_year`;

CREATE TABLE `school_year` (
  `sy_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(60) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`sy_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `school_year` */

insert  into `school_year`(`sy_id`,`school_year`,`status`,`date_added`) values 
(2,'2022-2023',0,'2023-01-21 00:25:13'),
(6,'2023-2024',1,'2024-02-21 22:14:11');

/*Table structure for table `students` */

DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_code` varchar(50) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `mname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `course_id` int(11) NOT NULL,
  `yl_id` int(11) NOT NULL,
  `sy_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `students` */

insert  into `students`(`student_id`,`student_code`,`fname`,`mname`,`lname`,`gender`,`email`,`contact`,`course_id`,`yl_id`,`sy_id`,`status`,`date_added`) values 
(1,'10140715','Cooper','Mark','D','male','aa@mgmail.com','09321456789',1,2,2,1,'2023-01-21 00:18:51'),
(2,'62314150','Blake','Claire','D','female','aa@fgmail.com','0977456789',2,1,2,1,'2023-01-21 00:22:37'),
(4,'623141505585','mohamed','','medo','male','ewewd@cded.ew','88555555888',1,1,2,1,'2023-01-22 23:30:57'),
(5,'7744168686109','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:20'),
(6,'7744168686','edwe','','ijie','male','aaa@gmail.com','888569699',2,2,2,1,'2023-01-23 21:23:53'),
(7,'77441686861','edwe','','ijie','male','aaa1@gmail.com','888569699',2,2,2,1,'2023-01-23 21:24:55'),
(8,'774416868610','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:25:26'),
(9,'7744168686101','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(10,'7744168686102','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(12,'7744168686104','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(13,'7744168686105','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(14,'7744168686106','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(15,'7744168686107','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:19'),
(16,'7744168686108','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:20'),
(17,'77441686861010','njndew','','eewe','male','a@a.aa','7777789501',1,1,2,1,'2023-01-23 21:26:20'),
(19,'777744580055','eew','','ewed','male','ed@gmail.com','7774110247788',2,1,2,1,'2023-01-24 01:34:14'),
(20,'12345','Jabbe Charles','','Erum','male','jabbecharles2@gmail.com','09461310444',4,1,6,1,'2024-02-21 22:17:13'),
(21,'23445','Alvin Jhay Carl','','Borre','male','bore@gmail.com','3241312432',1,1,6,1,'2024-02-21 23:00:42'),
(22,'123131','Sperry Migael','O','Parala','male','paralada@gmail.com','21342143242',2,1,6,1,'2024-02-21 23:08:17'),
(23,'232132141','Fredrine','','Miladona','male','miladona32131@gmail.com','241423542342',3,2,6,1,'2024-02-21 23:12:00');

/*Table structure for table `user_list` */

DROP TABLE IF EXISTS `user_list`;

CREATE TABLE `user_list` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(70) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_list` */

insert  into `user_list`(`user_id`,`fullname`,`username`,`password`,`type`,`status`,`date_added`) values 
(4,'Micky Angel','Micky123','$2y$10$aMgGNuQgxBhkDrUsuuaCruinjokqrUnOrtWQ4JpY.BJpSE3hdlrge',1,1,'2024-02-21 22:15:11'),
(5,'Jabbe Charles','Erum02','$2y$10$W14lGm0ylqtC4biwsS3PoeBSmh4N7kmgnSduO6sJrkhsIVZtjLTUO',2,1,'2024-02-21 22:15:53'),
(6,'Jabbe123','Jabbe123','$2y$10$VUBLzriR/3q2wyKkR2TwoekrTkbv4/wMbj.2XOFXIY/G/dSbw.3t2',1,1,'2024-02-21 22:24:23');

/*Table structure for table `year_level` */

DROP TABLE IF EXISTS `year_level`;

CREATE TABLE `year_level` (
  `yl_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`yl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `year_level` */

insert  into `year_level`(`yl_id`,`name`,`date_added`) values 
(1,'Third Year','2023-01-21 00:25:50'),
(2,'Second Year','2023-01-21 00:25:50'),
(3,'Fourth Year','2023-01-21 00:26:08'),
(4,'First Year','2023-01-21 00:26:08');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
